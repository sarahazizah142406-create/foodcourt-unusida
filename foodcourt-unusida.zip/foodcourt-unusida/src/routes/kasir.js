import { Router } from "express";
import rateLimit from "express-rate-limit";
import { authKasir } from "../middleware/authKasir.js";
import { parseImages } from "../middleware/upload.js";
import { wrap } from "../utils.js";
import {
  login, getMe, setKantinStatus, getDashboard, getOrdersMasuk, getOrderItems,
  updateStatusOrder, konfirmasiBayar, batalkanOrder, hapusOrder, bersihkanOrder, panggilPelanggan, listMenus, tambahMenu, updateMenu,
  updateStatusMenu, deleteMenu, getLaporan, registerPushToken, unregisterPushToken
} from "../controllers/kasirController.js";

const router = Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Terlalu banyak percobaan login, coba lagi 15 menit lagi" }
});

router.post("/login", loginLimiter, wrap(login));

router.use(authKasir);
router.get("/me", wrap(getMe));
router.patch("/status", wrap(setKantinStatus));
router.get("/dashboard", wrap(getDashboard));
router.get("/orders", wrap(getOrdersMasuk));
router.post("/orders/bersihkan", wrap(bersihkanOrder));
router.get("/orders/:orderTenantId/items", wrap(getOrderItems));
router.post("/orders/:orderTenantId/batal", wrap(batalkanOrder));
router.delete("/orders/:orderTenantId", wrap(hapusOrder));
router.patch("/orders/:orderTenantId/status", wrap(updateStatusOrder));
router.post("/orders/:orderTenantId/panggil", wrap(panggilPelanggan));
router.patch("/orders/:orderTenantId/bayar", wrap(konfirmasiBayar));
router.get("/menus", wrap(listMenus));
router.post("/menus", parseImages(["foto"]), wrap(tambahMenu));
router.put("/menus/:menuId", parseImages(["foto"]), wrap(updateMenu));
router.patch("/menus/:menuId/status", wrap(updateStatusMenu));
router.delete("/menus/:menuId", wrap(deleteMenu));
router.get("/laporan", wrap(getLaporan));
router.post("/push-token", wrap(registerPushToken));
router.delete("/push-token", wrap(unregisterPushToken));

export default router;
